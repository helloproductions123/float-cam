chrome.action.onClicked.addListener(async (tab) => {
  try {
    // Alert the tab script to render the activation interface overlay
    await chrome.tabs.sendMessage(tab.id, { action: "prompt_user_gesture" });
  } catch (err) {
    // Fallback if the script isn't running on the page yet
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    }, () => {
      chrome.tabs.sendMessage(tab.id, { action: "prompt_user_gesture" });
    });
  }
});
