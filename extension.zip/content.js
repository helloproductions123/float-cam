chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "prompt_user_gesture") {
    if (document.getElementById("pip-launcher-overlay")) return;

    if (!('documentPictureInPicture' in window)) {
      alert("Error: Your browser does not support Document Picture-in-Picture.");
      return;
    }

    // Resolve the internal URL path for the icon file asset
    const iconUrl = chrome.runtime.getURL("icon.png");

    const overlay = document.createElement("div");
    overlay.id = "pip-launcher-overlay";
    overlay.innerHTML = `
      <div style="
        position: fixed; top: 20px; right: 20px; z-index: 999999;
        background: #1a73e8; color: white; padding: 12px 20px;
        border-radius: 8px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3); cursor: pointer;
        font-weight: bold; transition: transform 0.2s, background 0.2s;
        display: flex; align-items: center; gap: 10px;
      " id="pip-launch-btn">
        <img src="${iconUrl}" style="width: 20px; height: 20px; object-fit: contain;" alt="">
        Click to Launch Floating Camera
      </div>
    `;
    document.body.appendChild(overlay);

    const button = document.getElementById("pip-launch-btn");
    button.onmouseenter = () => button.style.background = "#1557b0";
    button.onmouseleave = () => button.style.background = "#1a73e8";

    button.addEventListener("click", async () => {
      overlay.remove();

      try {
        const cameraStream = await navigator.mediaDevices.getUserMedia({ 
          video: { width: { ideal: 640 }, height: { ideal: 480 } }, 
          audio: false 
        });

        const targetWidth = 240; 
        const targetHeight = 180;

        const leftPosition = window.screen.availWidth - targetWidth;
        const topPosition = window.screen.availHeight - targetHeight;

        const pipWindow = await window.documentPictureInPicture.requestWindow({
          width: targetWidth,
          height: targetHeight,
          left: leftPosition,
          top: topPosition
        });

        // Set the window title name
        pipWindow.document.title = "School Cam";

        // Create and append the link tag into the window head context to override the favicon
        const faviconLink = pipWindow.document.createElement("link");
        faviconLink.rel = "icon";
        faviconLink.type = "image/png";
        faviconLink.href = iconUrl;
        pipWindow.document.head.appendChild(faviconLink);

        pipWindow.document.body.innerHTML = `
          <style>
            * { box-sizing: border-box; }
            body { 
              margin: 0; padding: 0; background: #000000; overflow: hidden; 
              display: flex; justify-content: center; align-items: center; 
              width: 100vw; height: 100vh;
            }
            video { 
              width: 100%; height: 100%; object-fit: cover; 
              transform: scaleX(-1);
            }
          </style>
          <video id="camView" autoplay playsinline muted></video>
        `;

        const videoElement = pipWindow.document.getElementById('camView');
        videoElement.srcObject = cameraStream;

        pipWindow.addEventListener("pagehide", () => {
          cameraStream.getTracks().forEach(track => track.stop());
        });

      } catch (error) {
        console.error("PiP execution failed:", error);
        alert("Could not start floating camera: " + error.message);
      }
    });
  }
});
